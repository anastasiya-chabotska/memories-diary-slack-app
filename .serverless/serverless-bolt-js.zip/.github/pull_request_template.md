###  Summary

Describe the goal of this pull request. Mention any related issue numbers from [slackapi/bolt-js/issues](https://github.com/slackapi/bolt-js/issues).

### Requirements (place an `x` in each `[ ]`)

* [ ] I've read and understood the [Contributing Guidelines](https://github.com/slackapi/bolt-js-getting-started-app/blob/main/.github/contributing.md) and have done my best effort to follow them.
* [ ] I've read and agree to the [Code of Conduct](https://slackhq.github.io/code-of-conduct).